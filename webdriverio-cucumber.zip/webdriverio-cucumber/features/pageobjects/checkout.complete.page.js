

import Page from './page.js';

/**
 * sub page containing specific selectors and methods for CheckoutCompletePage
 */
class CheckoutCompletePage extends Page {
    /**
     * selectors using getter methods
     */
    get thankYouOrderMessage() {
        return $('h2[class="complete-header"]')
    }
    get successOrderDispatchedTextMessage() {
        return $('div[class="complete-text"]')
    }
    get checkoutCompleteTitle() {
        return $('//span[@class="title" and text()="Checkout: Complete!"]')
    }
}

export default new CheckoutCompletePage();
