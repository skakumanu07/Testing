import { Given, When, Then } from '@wdio/cucumber-framework';

import LoginPage from '../pageobjects/login.page.js';
import InventoryPage from '../pageobjects/inventory.page.js';
import cartPage from '../pageobjects/cart.page.js';
import utilities from '../../utilities.js';
import checkoutYourInformationPage from '../pageobjects/checkout.your.information.page.js';
import checkoutOverviewPage from '../pageobjects/checkout.overview.page.js';
import checkoutCompletePage from '../pageobjects/checkout.complete.page.js';

const pages = {
    login: LoginPage
}

Given(/^I Login into the Application$/, async () => {
    await LoginPage.open();
    await browser.maximizeWindow();
    await LoginPage.login("standard_user", "secret_sauce")
});

Given(/^I am on the (\w+) page$/, async (page) => {
    await pages[page].open();
    await browser.maximizeWindow();
});

When(/^I login with (\w+) and (.+)$/, async (username, password) => {
    await LoginPage.login(username, password)
});

Then(/^I should see a message saying (.*)$/, async (message) => {
    await utilities.verifyElementExist(LoginPage.loginAlert, "Login Error");
    await utilities.verifyElementContainsText(LoginPage.loginAlert, message);
});
Then(/^I should be logged in and menu should display$/, async () => {
    await utilities.verifyElementExist(InventoryPage.burgerMenu, "Menu");
});
When(/^I select Price low to high sorting option from Products dropdown$/, async () => {
    await utilities.selectDropDownValue(InventoryPage.productSortDropdown,"value","lohi");
});
Then(/^I verify Products are sorted by Price low to high on the Inventory page$/, async () => {
    await expect(InventoryPage.inventoryItemPriceFirst).toHaveTextContaining('$7.99');
    console.log("Verified - Products are sorted by price low to high");
});
When(/^I select Price high to low sorting option from Products dropdown$/, async () => {
    await utilities.selectDropDownValue(InventoryPage.productSortDropdown,"value","hilo");
});
Then(/^I verify Products are sorted by Price high to low on the Inventory page$/, async () => {
    await expect(InventoryPage.inventoryItemPriceFirst).toHaveTextContaining('$49.99');
    console.log("Verified - Products are sorted by price high to low");
});
Then(/^I Add three items to the cart$/, async () => {
    const items = [InventoryPage.addToCartButtonSauceLabsBackpack, InventoryPage.addToCartButtonSauceLabsBoltTShirt, InventoryPage.addToCartButtonSauceLabsFleeceJacket]
    items.forEach(element => {
        utilities.doClick(element, "Add to Cart");
    });    
});
When(/^I click on the Cart button$/, async () => {
    await utilities.doClick(InventoryPage.cartButton, "Cart Button");  
});
Then(/^I should see the Cart page$/, async () => {
    await browser.pause(3000)
    await utilities.verifyElementExist(cartPage.yourCartLabel, "Cart Page");
});
Then(/^I remove Sauce Labs Backpack item$/, async () => {
    await utilities.doClick(cartPage.removeButtonSauceLabsBackpack, "Remove Button");
    await utilities.verifyElementNotExist(cartPage.sauceLabsBikeLightItem, "Sauce Labs Bike Light")
});
When(/^I click on the Checkout button$/, async () => {
    await utilities.doClick(cartPage.checkoutButton, "Checkout Button");  
});
Then(/^I should see Checkout Your Information page$/, async () => {
    await utilities.verifyElementExist(checkoutYourInformationPage.checkoutYourInformationTitle, "Checkout Your Information Title");
});
Then(/^I enter shipping information$/, async () => {
    await utilities.enterValueInTextbox(checkoutYourInformationPage.firstNameTextbox, "John", "First Name Textbox");
    await utilities.enterValueInTextbox(checkoutYourInformationPage.lastNameTextbox, "Smith", "Last Name Textbox");
    await utilities.enterValueInTextbox(checkoutYourInformationPage.postalCodeTextbox, "90001", "Postal Code Textbox");
});
When(/^I click on the Continue button$/, async () => {
    await utilities.doClick(checkoutYourInformationPage.continueButton, "Continue Button");  
});
Then(/^I should see Checkout Overview page$/, async () => {
    await utilities.verifyElementExist(checkoutOverviewPage.checkoutOverviewTitle, "Checkout Overview Title");
});
When(/^I click on the Finish button$/, async () => {
    await utilities.doClick(checkoutOverviewPage.finishButton, "Finish Button");  
});
Then(/^I should see Checkout Complete page$/, async () => {
    await utilities.verifyElementExist(checkoutCompletePage.checkoutCompleteTitle, "Checkout Complete Title");
});
Then(/^I should see Thank You Order message saying (.*)$/, async (message) => {
    await utilities.verifyElementExist(checkoutCompletePage.thankYouOrderMessage, "Thank Your Order Message");
    await utilities.verifyElementContainsText(checkoutCompletePage.thankYouOrderMessage, message);
});
Then(/^I should see Success message saying (.*)$/, async (message) => {
    await utilities.verifyElementExist(checkoutCompletePage.successOrderDispatchedTextMessage, "Success Order Dispatched Message");
    await utilities.verifyElementContainsText(checkoutCompletePage.successOrderDispatchedTextMessage, message);
});
