

import Page from './page.js';

/**
 * sub page containing specific selectors and methods for Inventory page
 */
class InventoryPage extends Page {
    /**
     * selectors using getter methods
     */
    get burgerMenu () {
        return $('#react-burger-menu-btn');
    }
    get productSortDropdown () {
        return $('select[data-test="product_sort_container"]')
    }
    get addToCartButtonSauceLabsFleeceJacket(){
        return $('#add-to-cart-sauce-labs-fleece-jacket')
    }
    get addToCartButtonSauceLabsBackpack(){
        return $('#add-to-cart-sauce-labs-backpack')
    }
    get addToCartButtonSauceLabsBoltTShirt() {
        return $('#add-to-cart-sauce-labs-bolt-t-shirt')
    }
    get cartButton() {
        return $('a[class="shopping_cart_link"]')
    }
    get inventoryItemPriceFirst() {
        return $('(//div[@class="inventory_item_price"])[1]')
    }
    get inventoryItemPriceList() {
        return $('(//div[@class="inventory_item_price"])')
    }
}

export default new InventoryPage();
