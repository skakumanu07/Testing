

import Page from './page.js';

/**
 * sub page containing specific selectors and methods for CheckoutOverviewPage
 */
class CheckoutOverviewPage extends Page {
    /**
     * selectors using getter methods
     */
    get finishButton() {
        return $('#finish')
    }
    get checkoutOverviewTitle() {
        return $('span[class="title"]')
    }
    get checkoutOverviewTitle() {
        return $('//span[@class="title" and text()="Checkout: Overview"]')
    }
}

export default new CheckoutOverviewPage();
