

import Page from './page.js';

/**
 * sub page containing specific selectors and methods for Cart page
 */
class CartPage extends Page {
    /**
     * selectors using getter methods
     */
    get cartQuantityTextbox() {
        return $('div[class="cart_quantity"]')
    }
    get removeButtonSauceLabsBackpack() {
        return $('#remove-sauce-labs-backpack')
    }
    get checkoutButton() {
        return $('#checkout')
    }
    get yourCartLabel() {
        return $('//span[@class="title" and text()="Your Cart"]')
    }
    get sauceLabsBackpackItem() {
        return $('//div[@class="inventory_item_name" and text()="Sauce Labs Backpack"]')
    }
}

export default new CartPage();
