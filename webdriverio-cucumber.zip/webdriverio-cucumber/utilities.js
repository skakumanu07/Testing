/**
 * utility methods for elements
 */
class Utilities {

    /**
     * a method to verify element exists
     */
    async verifyElementExist (element, elementName) {
        await expect(element).toBeExisting();
        console.log(`${elementName} is displaying`);
    }
    async verifyElementNotExist (element, elementName) {
        try {
            let isExisting = element.isExisting();
            console.log(isExisting);
            if(isExisting === false){
                console.log(`${elementName} does not exist`);
            }
            else{
                throw "error: element exist"
            }            
        } catch (error) {
            console.log(error);
        }
    }
    async verifyElementContainsText (element, text) {
        await expect(element).toHaveTextContaining(text);
        console.log(`${text} text is displaying`);
    }
    async doClick(element, elementName) {
        await element.click();
        console.log(`CLicked on ${elementName}`);
    }
    async selectDropDownValue(element, attribute, value){
        await element.selectByAttribute(attribute, value);
        console.log(`Selected value ${value} from the dropdown`);
    }
    async enterValueInTextbox(element, value, elementName){
        await element.addValue(value);
        console.log(`Entered Text in ${elementName}`);
    }
}

export default new Utilities();
