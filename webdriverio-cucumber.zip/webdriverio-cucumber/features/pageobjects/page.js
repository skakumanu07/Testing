/**
* main page object containing all methods, selectors and functionality
* that is shared across all page objects
*/
export default class Page {
    /**
    * Opens a Login page of the page
    */
    open () {
        return browser.url('https://www.saucedemo.com/')
    }
}
