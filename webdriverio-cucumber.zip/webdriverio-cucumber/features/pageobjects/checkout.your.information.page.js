

import Page from './page.js';

/**
 * sub page containing specific selectors and methods for CheckoutYourInformationPage
 */
class CheckoutYourInformationPage extends Page {
    /**
     * selectors using getter methods
     */
    get firstNameTextbox() {
        return $('#first-name')
    }
    get lastNameTextbox() {
        return $('#last-name')
    }
    get postalCodeTextbox() {
        return $('#postal-code')
    }
    get continueButton() {
        return $('#continue')
    }
    get checkoutYourInformationTitle() {
        return $('//span[@class="title" and text()="Checkout: Your Information"]')
    }
}

export default new CheckoutYourInformationPage();
