

import Page from './page.js';

/**
 * sub page containing specific selectors and methods for Secure page
 */
class SecurePage extends Page {
    /**
     * selectors using getter methods
     */
    get loginAlert () {
        return $('h3[data-test="error"]');
    }
}

export default new SecurePage();
